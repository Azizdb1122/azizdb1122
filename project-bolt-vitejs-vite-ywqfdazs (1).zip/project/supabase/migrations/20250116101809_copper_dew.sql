-- Create function to get global leaderboard
CREATE OR REPLACE FUNCTION get_global_leaderboard()
RETURNS TABLE (
  id uuid,
  first_name text,
  last_name text,
  nationality text,
  points integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.first_name,
    p.last_name,
    p.nationality,
    COALESCE(pt.points, 0) as points
  FROM profiles p
  LEFT JOIN points pt ON p.id = pt.user_id
  ORDER BY pt.points DESC NULLS LAST
  LIMIT 10;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get gender-specific leaderboard
CREATE OR REPLACE FUNCTION get_gender_leaderboard(user_gender text)
RETURNS TABLE (
  id uuid,
  first_name text,
  last_name text,
  nationality text,
  points integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.first_name,
    p.last_name,
    p.nationality,
    COALESCE(pt.points, 0) as points
  FROM profiles p
  LEFT JOIN points pt ON p.id = pt.user_id
  WHERE p.gender = user_gender
  ORDER BY pt.points DESC NULLS LAST
  LIMIT 10;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;