/*
  # Points and Challenges System

  1. New Tables
    - `points`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `points` (integer)
      - `last_activity` (timestamptz)
      - `created_at` (timestamptz)
    
    - `challenges`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `points` (integer)
      - `created_at` (timestamptz)
    
    - `user_challenges`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `challenge_id` (uuid, references challenges)
      - `completed` (boolean)
      - `points_earned` (integer)
      - `completed_at` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add appropriate policies for each table
*/

-- Points table
CREATE TABLE IF NOT EXISTS points (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  points integer DEFAULT 0,
  last_activity timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Challenges table
CREATE TABLE IF NOT EXISTS challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  points integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- User challenges table
CREATE TABLE IF NOT EXISTS user_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  challenge_id uuid REFERENCES challenges(id) ON DELETE CASCADE,
  completed boolean DEFAULT false,
  points_earned integer DEFAULT 0,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE points ENABLE ROW LEVEL SECURITY;
ALTER TABLE challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_challenges ENABLE ROW LEVEL SECURITY;

-- Points policies
CREATE POLICY "Users can view their own points"
  ON points FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert points"
  ON points FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "System can update points"
  ON points FOR UPDATE
  USING (auth.uid() = user_id);

-- Challenges policies
CREATE POLICY "Anyone can view challenges"
  ON challenges FOR SELECT
  TO authenticated
  USING (true);

-- User challenges policies
CREATE POLICY "Users can view their own challenges"
  ON user_challenges FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own challenges"
  ON user_challenges FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert user challenges"
  ON user_challenges FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Function to update points periodically
CREATE OR REPLACE FUNCTION update_user_points()
RETURNS void AS $$
BEGIN
  UPDATE points
  SET points = points + 100,
      last_activity = now()
  WHERE last_activity < now() - interval '1 minute'
  AND user_id IN (
    SELECT id FROM profiles
    WHERE id IN (
      SELECT user_id FROM points
    )
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to generate random challenge
CREATE OR REPLACE FUNCTION generate_random_challenge(user_id uuid)
RETURNS void AS $$
DECLARE
  new_challenge_id uuid;
  challenge_points integer;
BEGIN
  -- Generate random points between 0 and 100
  challenge_points := floor(random() * 101);
  
  -- Create new challenge
  INSERT INTO challenges (title, description, points)
  VALUES (
    'تحدي جديد #' || floor(random() * 1000)::text,
    'أكمل هذا التحدي للحصول على ' || challenge_points::text || ' نقطة!',
    challenge_points
  )
  RETURNING id INTO new_challenge_id;
  
  -- Assign challenge to user
  INSERT INTO user_challenges (user_id, challenge_id)
  VALUES (user_id, new_challenge_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;