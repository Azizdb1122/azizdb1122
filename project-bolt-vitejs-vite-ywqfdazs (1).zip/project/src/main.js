import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import { createI18n } from 'vue-i18n'
import App from './App.vue'
import './style.css'

// Routes
import Login from './views/Login.vue'
import Register from './views/Register.vue'
import ForgotPassword from './views/ForgotPassword.vue'
import ResetPassword from './views/ResetPassword.vue'
import VerifyEmail from './views/VerifyEmail.vue'
import Dashboard from './views/Dashboard.vue'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', redirect: '/login' },
    { path: '/login', component: Login },
    { path: '/register', component: Register },
    { path: '/forgot-password', component: ForgotPassword },
    { path: '/reset-password', component: ResetPassword },
    { path: '/verify-email', component: VerifyEmail },
    { path: '/dashboard', component: Dashboard }
  ]
})

const i18n = createI18n({
  locale: 'ar',
  messages: {
    ar: {
      login: {
        title: 'تسجيل الدخول',
        email: 'البريد الإلكتروني',
        password: 'كلمة المرور',
        submit: 'دخول',
        forgotPassword: 'نسيت كلمة المرور؟',
        noAccount: 'ليس لديك حساب؟',
        register: 'إنشاء حساب جديد'
      },
      register: {
        title: 'إنشاء حساب جديد',
        firstName: 'الاسم الأول',
        lastName: 'اسم العائلة',
        email: 'البريد الإلكتروني',
        password: 'كلمة المرور',
        confirmPassword: 'تأكيد كلمة المرور',
        gender: 'الجنس',
        male: 'ذكر',
        female: 'أنثى',
        nationality: 'الجنسية',
        birthDate: 'تاريخ الميلاد',
        phone: 'رقم الهاتف',
        submit: 'إنشاء الحساب'
      }
    }
  }
})

const app = createApp(App)
app.use(router)
app.use(i18n)
app.mount('#app')