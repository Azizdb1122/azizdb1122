<template>
  <div class="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500">
    <router-view></router-view>
  </div>
</template>

<script setup>
import { supabase } from './supabase'
</script>