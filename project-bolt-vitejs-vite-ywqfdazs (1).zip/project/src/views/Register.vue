<template>
  <div class="min-h-screen flex items-center justify-center py-12 px-4">
    <div class="max-w-2xl w-full bg-white rounded-lg shadow-lg p-8">
      <h2 class="text-3xl font-bold text-center mb-8">{{ $t('register.title') }}</h2>
      
      <!-- Error Alert -->
      <div v-if="error" class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
        <span class="block sm:inline">{{ errorMessage }}</span>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3" @click="error = null">
          <svg class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
            <title>Close</title>
            <path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/>
          </svg>
        </span>
      </div>

      <form @submit.prevent="handleRegister" class="space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.firstName') }}</label>
            <input
              type="text"
              v-model="form.firstName"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.lastName') }}</label>
            <input
              type="text"
              v-model="form.lastName"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.email') }}</label>
            <input
              type="email"
              v-model="form.email"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.phone') }}</label>
            <input
              type="tel"
              v-model="form.phone"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.password') }}</label>
            <input
              type="password"
              v-model="form.password"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.confirmPassword') }}</label>
            <input
              type="password"
              v-model="form.confirmPassword"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.gender') }}</label>
            <select
              v-model="form.gender"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            >
              <option value="male">{{ $t('register.male') }}</option>
              <option value="female">{{ $t('register.female') }}</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.nationality') }}</label>
            <select
              v-model="form.nationality"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            >
              <option value="SA">المملكة العربية السعودية</option>
              <option value="AE">الإمارات العربية المتحدة</option>
              <option value="KW">الكويت</option>
              <option value="BH">البحرين</option>
              <option value="OM">عمان</option>
              <option value="QA">قطر</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">{{ $t('register.birthDate') }}</label>
            <input
              type="date"
              v-model="form.birthDate"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
            />
          </div>
        </div>
        <button
          type="submit"
          :disabled="loading"
          class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400"
        >
          {{ loading ? 'جاري التسجيل...' : $t('register.submit') }}
        </button>
      </form>

      <!-- Login Link -->
      <div class="mt-6 text-center">
        <p class="text-sm text-gray-600">
          لديك حساب بالفعل؟
          <router-link to="/login" class="font-medium text-indigo-600 hover:text-indigo-500">
            تسجيل الدخول
          </router-link>
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { supabase } from '../supabase'

const router = useRouter()
const loading = ref(false)
const error = ref(null)
const errorMessage = ref('')

const form = ref({
  firstName: '',
  lastName: '',
  email: '',
  password: '',
  confirmPassword: '',
  gender: '',
  nationality: '',
  birthDate: '',
  phone: ''
})

const handleRegister = async () => {
  error.value = null
  errorMessage.value = ''

  if (form.value.password !== form.value.confirmPassword) {
    error.value = true
    errorMessage.value = 'كلمات المرور غير متطابقة'
    return
  }

  loading.value = true
  try {
    // Check if user exists first
    const { data: existingUser } = await supabase
      .from('profiles')
      .select('email')
      .eq('email', form.value.email)
      .single()

    if (existingUser) {
      error.value = true
      errorMessage.value = 'البريد الإلكتروني مسجل بالفعل'
      return
    }

    const { error: signUpError } = await supabase.auth.signUp({
      email: form.value.email,
      password: form.value.password,
      options: {
        data: {
          first_name: form.value.firstName,
          last_name: form.value.lastName,
          gender: form.value.gender,
          nationality: form.value.nationality,
          birth_date: form.value.birthDate,
          phone: form.value.phone
        }
      }
    })

    if (signUpError) {
      error.value = true
      if (signUpError.message === 'User already registered') {
        errorMessage.value = 'البريد الإلكتروني مسجل بالفعل'
      } else {
        errorMessage.value = 'حدث خطأ أثناء التسجيل. الرجاء المحاولة مرة أخرى'
      }
      return
    }

    router.push('/verify-email')
  } catch (err) {
    error.value = true
    errorMessage.value = 'حدث خطأ غير متوقع. الرجاء المحاولة مرة أخرى'
  } finally {
    loading.value = false
  }
}
</script>