<template>
  <div class="min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8 text-center">
      <h2 class="text-3xl font-bold mb-8">تحقق من بريدك الإلكتروني</h2>
      <p class="text-gray-600 mb-6">
        تم إرسال رابط التحقق إلى بريدك الإلكتروني. الرجاء التحقق من صندوق الوارد الخاص بك.
      </p>
      <button
        @click="resendVerification"
        :disabled="resendTimer > 0"
        class="text-indigo-600 hover:text-indigo-500"
      >
        {{ resendTimer > 0 ? `إعادة الإرسال بعد ${resendTimer} ثانية` : 'إعادة إرسال رابط التحقق' }}
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { supabase } from '../supabase'

const resendTimer = ref(0)

const startResendTimer = () => {
  resendTimer.value = 60
  const timer = setInterval(() => {
    resendTimer.value--
    if (resendTimer.value === 0) {
      clearInterval(timer)
    }
  }, 1000)
}

const resendVerification = async () => {
  if (resendTimer.value > 0) return
  try {
    // In a real application, resend verification email
    startResendTimer()
  } catch (error) {
    alert(error.message)
  }
}

// Start timer on component mount
startResendTimer()
</script>