<template>
  <div class="min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
      <h2 class="text-3xl font-bold text-center mb-8">تعيين كلمة المرور الجديدة</h2>
      <form @submit.prevent="handleResetPassword" class="space-y-6">
        <div>
          <label class="block text-sm font-medium text-gray-700">كلمة المرور الجديدة</label>
          <input
            type="password"
            v-model="newPassword"
            required
            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          />
          <div class="mt-2">
            <ul class="text-sm text-gray-600 space-y-1">
              <li :class="{ 'text-green-600': hasLength }">✓ 12 حرف على الأقل</li>
              <li :class="{ 'text-green-600': hasUpperCase }">✓ حرف كبير واحد على الأقل</li>
              <li :class="{ 'text-green-600': hasLowerCase }">✓ حرف صغير واحد على الأقل</li>
              <li :class="{ 'text-green-600': hasNumber }">✓ رقم واحد على الأقل</li>
              <li :class="{ 'text-green-600': hasSpecial }">✓ رمز خاص واحد على الأقل</li>
            </ul>
          </div>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700">تأكيد كلمة المرور الجديدة</label>
          <input
            type="password"
            v-model="confirmPassword"
            required
            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
          />
        </div>
        <button
          type="submit"
          :disabled="!isPasswordValid"
          class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400"
        >
          تعيين كلمة المرور
        </button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { supabase } from '../supabase'

const router = useRouter()
const newPassword = ref('')
const confirmPassword = ref('')

const hasLength = computed(() => newPassword.value.length >= 12)
const hasUpperCase = computed(() => /[A-Z]/.test(newPassword.value))
const hasLowerCase = computed(() => /[a-z]/.test(newPassword.value))
const hasNumber = computed(() => /[0-9]/.test(newPassword.value))
const hasSpecial = computed(() => /[!@#$%^&*(),.?":{}|<>]/.test(newPassword.value))

const isPasswordValid = computed(() => 
  hasLength.value && 
  hasUpperCase.value && 
  hasLowerCase.value && 
  hasNumber.value && 
  hasSpecial.value &&
  newPassword.value === confirmPassword.value
)

const handleResetPassword = async () => {
  if (!isPasswordValid.value) {
    alert('الرجاء التأكد من استيفاء جميع شروط كلمة المرور')
    return
  }

  try {
    const { error } = await supabase.auth.updateUser({
      password: newPassword.value
    })
    if (error) throw error
    router.push('/login')
  } catch (error) {
    alert(error.message)
  }
}
</script>