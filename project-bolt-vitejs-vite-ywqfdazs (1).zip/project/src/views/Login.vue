<template>
  <div class="min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full backdrop-blur-lg bg-white/30 rounded-2xl shadow-2xl p-8 border border-white/20">
      <h2 class="text-4xl font-bold text-center mb-8 text-white">{{ $t('login.title') }}</h2>
      <form @submit.prevent="handleLogin" class="space-y-6">
        <div class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-white">{{ $t('login.email') }}</label>
            <input
              type="email"
              v-model="email"
              required
              class="mt-1 block w-full rounded-xl border-0 bg-white/10 p-3 text-white placeholder-white/50 shadow-sm ring-1 ring-inset ring-white/20 focus:ring-2 focus:ring-white"
              placeholder="example@email.com"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-white">{{ $t('login.password') }}</label>
            <input
              type="password"
              v-model="password"
              required
              class="mt-1 block w-full rounded-xl border-0 bg-white/10 p-3 text-white placeholder-white/50 shadow-sm ring-1 ring-inset ring-white/20 focus:ring-2 focus:ring-white"
              placeholder="••••••••"
            />
          </div>
          <div class="flex items-center justify-end">
            <router-link to="/forgot-password" class="text-sm text-white hover:text-white/80 transition-colors">
              {{ $t('login.forgotPassword') }}
            </router-link>
          </div>
          <button
            type="submit"
            class="w-full flex justify-center py-3 px-4 rounded-xl text-base font-semibold text-white bg-white/20 hover:bg-white/30 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {{ $t('login.submit') }}
          </button>
        </div>
      </form>
      <div class="mt-6 text-center">
        <p class="text-sm text-white">
          {{ $t('login.noAccount') }}
          <router-link to="/register" class="font-semibold hover:text-white/80 transition-colors">
            {{ $t('login.register') }}
          </router-link>
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { supabase } from '../supabase'

const router = useRouter()
const email = ref('')
const password = ref('')

const handleLogin = async () => {
  try {
    const { error } = await supabase.auth.signInWithPassword({
      email: email.value,
      password: password.value
    })
    if (error) throw error
    router.push('/dashboard')
  } catch (error) {
    alert(error.message)
  }
}
</script>