<template>
  <div class="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500">
    <div class="container mx-auto px-4 py-8">
      <!-- Points Section -->
      <div class="bg-white/30 backdrop-blur-lg rounded-xl p-6 mb-8">
        <div class="text-center">
          <h2 class="text-4xl font-bold text-white mb-4">نقاطك</h2>
          <p class="text-6xl font-bold text-white">{{ userPoints }}</p>
          <p class="text-sm text-white/80 mt-2">تزداد النقاط تلقائياً كل دقيقة</p>
        </div>
      </div>

      <!-- Current Challenge -->
      <div v-if="currentChallenge" class="bg-white/30 backdrop-blur-lg rounded-xl p-6 mb-8">
        <h3 class="text-2xl font-bold text-white mb-4">التحدي الحالي</h3>
        <div class="bg-white/20 rounded-lg p-4">
          <h4 class="text-xl font-semibold text-white mb-2">{{ currentChallenge.title }}</h4>
          <p class="text-white/90 mb-4">{{ currentChallenge.description }}</p>
          <div class="flex justify-between items-center">
            <span class="text-white/80">{{ currentChallenge.points }} نقطة</span>
            <button
              @click="completeChallenge"
              class="bg-white/20 hover:bg-white/30 text-white font-bold py-2 px-4 rounded-lg transition-all"
              :disabled="completing"
            >
              {{ completing ? 'جاري الإكمال...' : 'إكمال التحدي' }}
            </button>
          </div>
        </div>
      </div>

      <!-- Leaderboards -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <!-- Global Leaderboard -->
        <div class="bg-white/30 backdrop-blur-lg rounded-xl p-6">
          <h3 class="text-2xl font-bold text-white mb-4">لوحة الصدارة العالمية</h3>
          <div class="space-y-4">
            <div v-for="(user, index) in globalLeaderboard" :key="user.id"
              class="flex items-center bg-white/20 rounded-lg p-4">
              <span class="text-2xl font-bold text-white w-8">{{ index + 1 }}</span>
              <div class="flex-1 mx-4">
                <p class="text-white font-semibold">{{ user.first_name }} {{ user.last_name }}</p>
                <p class="text-white/80 text-sm">{{ user.nationality }}</p>
              </div>
              <span class="text-white font-bold">{{ user.points }}</span>
            </div>
          </div>
        </div>

        <!-- Gender-specific Leaderboard -->
        <div class="bg-white/30 backdrop-blur-lg rounded-xl p-6">
          <h3 class="text-2xl font-bold text-white mb-4">
            لوحة الصدارة - {{ userGender === 'male' ? 'الذكور' : 'الإناث' }}
          </h3>
          <div class="space-y-4">
            <div v-for="(user, index) in genderLeaderboard" :key="user.id"
              class="flex items-center bg-white/20 rounded-lg p-4">
              <span class="text-2xl font-bold text-white w-8">{{ index + 1 }}</span>
              <div class="flex-1 mx-4">
                <p class="text-white font-semibold">{{ user.first_name }} {{ user.last_name }}</p>
                <p class="text-white/80 text-sm">{{ user.nationality }}</p>
              </div>
              <span class="text-white font-bold">{{ user.points }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { supabase } from '../supabase'
import { useRouter } from 'vue-router'

const router = useRouter()
const userPoints = ref(0)
const currentChallenge = ref(null)
const globalLeaderboard = ref([])
const genderLeaderboard = ref([])
const userGender = ref('male')
const completing = ref(false)

// Fetch initial data
const fetchData = async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/login')
      return
    }

    // Fetch user profile
    const { data: profile } = await supabase
      .from('profiles')
      .select('gender')
      .eq('id', user.id)
      .single()
    
    if (profile) {
      userGender.value = profile.gender
    }

    // Fetch points
    const { data: points } = await supabase
      .from('points')
      .select('*')
      .eq('user_id', user.id)
    
    if (points && points.length > 0) {
      userPoints.value = points[0].points
    } else {
      // Create initial points record
      const { data: newPoints } = await supabase
        .from('points')
        .insert([{ user_id: user.id, points: 0 }])
        .select()
      
      if (newPoints) {
        userPoints.value = newPoints[0].points
      }
    }

    // Fetch current challenge
    const { data: challenges } = await supabase
      .from('user_challenges')
      .select(`
        challenge_id,
        challenges (
          id,
          title,
          description,
          points
        )
      `)
      .eq('user_id', user.id)
      .eq('completed', false)
      .order('created_at', { ascending: false })
      .limit(1)
    
    if (challenges && challenges.length > 0) {
      currentChallenge.value = challenges[0].challenges
    }

    // Fetch global leaderboard using a join
    const { data: global } = await supabase
      .rpc('get_global_leaderboard')

    if (global) {
      globalLeaderboard.value = global
    }

    // Fetch gender-specific leaderboard using a join
    const { data: gender } = await supabase
      .rpc('get_gender_leaderboard', { user_gender: userGender.value })

    if (gender) {
      genderLeaderboard.value = gender
    }
  } catch (error) {
    console.error('Error fetching data:', error)
  }
}

// Update points periodically
const pointsInterval = setInterval(async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    await supabase.rpc('update_user_points')
    await fetchData()
  } catch (error) {
    console.error('Error updating points:', error)
  }
}, 60000) // Every minute

// Generate new challenge periodically
const challengeInterval = setInterval(async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    await supabase.rpc('generate_random_challenge', { user_id: user.id })
    await fetchData()
  } catch (error) {
    console.error('Error generating challenge:', error)
  }
}, 300000) // Every 5 minutes

// Complete challenge
const completeChallenge = async () => {
  if (!currentChallenge.value || completing.value) return
  
  completing.value = true
  try {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    // Update challenge status
    await supabase
      .from('user_challenges')
      .update({
        completed: true,
        points_earned: currentChallenge.value.points,
        completed_at: new Date().toISOString()
      })
      .eq('user_id', user.id)
      .eq('challenge_id', currentChallenge.value.id)

    // Update user points
    await supabase
      .from('points')
      .update({
        points: userPoints.value + currentChallenge.value.points
      })
      .eq('user_id', user.id)

    // Refresh data
    await fetchData()
  } catch (error) {
    console.error('Error completing challenge:', error)
  } finally {
    completing.value = false
  }
}

// Initial fetch
onMounted(() => {
  fetchData()
})

// Cleanup
onUnmounted(() => {
  clearInterval(pointsInterval)
  clearInterval(challengeInterval)
})
</script>