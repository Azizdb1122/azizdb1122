<template>
  <div class="min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
      <h2 class="text-3xl font-bold text-center mb-8">استعادة كلمة المرور</h2>
      <div v-if="!verificationSent">
        <form @submit.prevent="handleForgotPassword" class="space-y-6">
          <div>
            <label class="block text-sm font-medium text-gray-700">البريد الإلكتروني</label>
            <input
              type="email"
              v-model="email"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">رقم الهاتف المسجل</label>
            <input
              type="tel"
              v-model="phone"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">تاريخ الميلاد</label>
            <input
              type="date"
              v-model="birthDate"
              required
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
          </div>
          <button
            type="submit"
            class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
          >
            إرسال رمز التحقق
          </button>
        </form>
      </div>
      <div v-else>
        <form @submit.prevent="handleVerifyCode" class="space-y-6">
          <div>
            <label class="block text-sm font-medium text-gray-700">رمز التحقق</label>
            <div class="grid grid-cols-6 gap-2 mt-1">
              <input
                v-for="(digit, index) in verificationCode"
                :key="index"
                type="text"
                maxlength="1"
                v-model="verificationCode[index]"
                @input="handleCodeInput($event, index)"
                class="w-full text-center rounded-md border-gray-300 shadow-sm"
              />
            </div>
          </div>
          <div class="text-center">
            <p class="text-sm text-gray-600">
              لم يصلك الرمز؟
              <button
                type="button"
                @click="resendCode"
                :disabled="resendTimer > 0"
                class="text-indigo-600 hover:text-indigo-500"
              >
                {{ resendTimer > 0 ? `إعادة الإرسال بعد ${resendTimer} ثانية` : 'إعادة إرسال الرمز' }}
              </button>
            </p>
          </div>
          <button
            type="submit"
            class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
          >
            تحقق من الرمز
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { supabase } from '../supabase'

const router = useRouter()
const email = ref('')
const phone = ref('')
const birthDate = ref('')
const verificationSent = ref(false)
const verificationCode = ref(['', '', '', '', '', ''])
const resendTimer = ref(0)

const handleForgotPassword = async () => {
  try {
    // In a real application, verify user details against database
    verificationSent.value = true
    startResendTimer()
  } catch (error) {
    alert(error.message)
  }
}

const handleCodeInput = (event, index) => {
  const value = event.target.value
  if (value && index < 5) {
    document.querySelectorAll('input')[index + 1].focus()
  }
}

const handleVerifyCode = async () => {
  const code = verificationCode.value.join('')
  if (code.length !== 6) {
    alert('الرجاء إدخال رمز التحقق كاملاً')
    return
  }
  
  try {
    // In a real application, verify the code
    router.push('/reset-password')
  } catch (error) {
    alert(error.message)
  }
}

const startResendTimer = () => {
  resendTimer.value = 60
  const timer = setInterval(() => {
    resendTimer.value--
    if (resendTimer.value === 0) {
      clearInterval(timer)
    }
  }, 1000)
}

const resendCode = async () => {
  if (resendTimer.value > 0) return
  try {
    // Resend verification code
    startResendTimer()
  } catch (error) {
    alert(error.message)
  }
}
</script>